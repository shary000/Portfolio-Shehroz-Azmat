export const firebaseConfig = {
  apiKey: "AIzaSyAxuntYACCRJJj37Q-fw9wKvpC_0X-rlwg",
  authDomain: "fir-d814f.firebaseapp.com",
  projectId: "fir-d814f",
  storageBucket: "fir-d814f.firebasestorage.app",
  messagingSenderId: "181746195254",
  appId: "1:181746195254:android:c34a937e2a22b84850b197",
};

export const googleAuthConfig = {
  expoClientId:
    "181746195254-eg70mml15plp2nt4e2eoicf1fqj37irb.apps.googleusercontent.com",
  // iosClientId: 'YOUR_IOS_CLIENT_ID',  // Disabled for now
  androidClientId:
    "181746195254-eg70mml15plp2nt4e2eoicf1fqj37irb.apps.googleusercontent.com",
  webClientId:
    "181746195254-eg70mml15plp2nt4e2eoicf1fqj37irb.apps.googleusercontent.com",
};
